<?php

class MyPayment extends MyPayment_parent{
    public function __construct(){
        parent::__construct();
        $this->printJS();
        if($_POST['fnc'] == 'validatepayment' ){
          $note = oxSession::getVar('ordrem');
          $branch = "";
          if(isset($_POST['branch_name_street'])){
            $branch = $_POST['branch_name_street'];
          }
          $note = preg_replace('/\[Zásilkovna\s*;\s*[0-9]+\s*;\s*[^\]]*\]/', '', $note);
          $note = $branch.' '.$note;
          oxSession::setVar('ordrem',$note);
        }?>
            
        <?php
    }


    private function printJS() {
      $myconfig = $this->getConfig();
      ?>
      <div class="packetery-branch-list list-type=7"><script> (function(d){ var el, id = "packetery-jsapi", head = d.getElementsByTagName("head")[0]; var lh = location.href;  el = d.createElement("script"); el.id = id; el.async = true; el.src = "http://www.zasilkovna.cz/api/<?php echo $myconfig->getConfigParam("zasilkovna_api_key");?>/branch.js?callback=addHooks"; head.insertBefore(el, head.firstChild); }(document)); </script></div>                
    
      <script language="javascript" type="text/javascript">
          function addHooks() {
      
              //checks all zasilkovbna select boxes and if radio is selected, set required param
              function setRequiredOpt() {
                  $("div.packetery-branch-list").each(
      
                  function () {
                      if (typeof this.packetery == 'undefined') return; //it is not the real select box
                      dl = $(this).parents('dl');
                      radio = dl.find('input:radio');
                      select_branch_message = dl.find('p[name="select_branch_message"]');
                      if (radio.is(':checked')) {
                          this.packetery.option('required', true);    
                          if (this.packetery.option("selected-id") > 0) {
                              select_branch_message.css('display', 'none');
                          } else {
                              console.log("not_selected_branch");
                              select_branch_message.css('display', 'block');
                          }
                      } else {
                          this.packetery.option('required', false);
                          if (this.packetery.option("selected-id") > 0) {
                            this.packetery.option("selected-id",0);
                          }
                          select_branch_message.css('display', 'none');
                      }
                  });
              }
      
              //set each radio button to call setRequiredOpt if clicked
              $('input[name="paymentid"]:radio').each(  
                function () {
                  $(this).click(setRequiredOpt);
              });

              

      
              //set onchange for each zasilkovna select box to update name_street input
              $("div").each(      
                function () {
                  if (typeof this.packetery == 'undefined') return; //it is not the real select box
                  if($('#branch_name_street').length==0)$(this).parents('form').append('<input type="hidden" name="branch_name_street" id="branch_name_street">')

                  console.log(this);
                  fn = function () {
                      setRequiredOpt();
                  }
                  this.packetery.on("branch-change", fn);
                  $(this).append('<p name="select_branch_message" style="color:red; font-weight:bold;display:none">Vyberte pobočku</p>');                  
                  this.packetery.option("selected-id",0);
              });
          }
      </script>

      <?php
    }
}